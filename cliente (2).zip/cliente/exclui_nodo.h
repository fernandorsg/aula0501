void exclui_nodo(NODO *lista);
