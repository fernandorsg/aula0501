void exclui_nodo(NODO *lista){
	if(*lista.f < 1){
		printf("Nao existem pacientes cadastrados.");
	}
	else{
		printf("Codigo - Paciente")
		for(int i = 0; i <= *lista.info[N_MAX]; i++){
			printf("%d - %s", *lista.info[i].codigo, *lista.info[i].nome);
		}
	}
	
	return lista;
}
