void exclui_nodo(NODO *lista){	
	int codExclusao;

	if(*lista.f < 1){
		printf("A lista esta vazia, nao existem pacientes cadastrados.\n");
	}
	else{
		printf("Codigo - Paciente\n");
		for(int i = 0; i <= *lista.info[N_MAX]; i++){
			printf("%d - %s\n", *lista.info[i].codigo, *lista.info[i].nome);
		}
		
		printf("Digite o codigo do paciente para a exclusao: ");
		scanf("%d", &codExclusao);
		
		if(codExclusao == ""){
			printf("Opcao invalida!!!\n");
			printf("Digite o codigo do paciente para a exclusao: ");
			scanf("%d", &codExclusao);
		}
		else{
			for(int j = 0; j <= *lista.info[N_MAX]; j++){
				if(codExclusao == *lista.info[j].codigo){
					*lista.info[j].codigo = "";
					*lista.info[j].nome = "";
				
					for (int m = j; m <= N_MAX; m++){
						*lista.info[m].codigo = *lista.info[m].codigo[m + 1];
						*lista.info[m].nome = *lista.info[m].nome[m + 1];
					}
				}
			}
		}
	}
	
	return lista;
}

void menuExclusao(){
	
	
	
}