#include <stdio.h>
#include <stdlib.h>
#include "exclui_nodo.h"
/***********************************************/ 
/* Defini��o dos Registros                     */
/***********************************************/ 
#define N_MAX 20
typedef struct {			// registro para uma pessoa       
	int codigo;       
	char nome[30];
}INFORMACAO;       
typedef struct {       
	INFORMACAO info[N_MAX];	// dados do registro       
	int f;					// n�mero de registro(s) ocupado(s) na estrutura
}NODO;						// estrutura do tipo NODO

 
/***********************************************/
/* Programa Principal                          */
/***********************************************/
int main(void){
	NODO lista;				// vari�vel do tipo lista sequencial = vetor de registros
	
	lista.info[0].codigo = 1;
	lista.info[0].nome = "Joao";
	lista.info[1].codigo = 2;
	lista.info[1].nome = "Jose";
	lista.info[2].codigo = 3;
	lista.info[2].nome = "Mario";
	
	exclui_nodo(lista);
}
