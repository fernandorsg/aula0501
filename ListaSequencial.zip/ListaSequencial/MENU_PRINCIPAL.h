/*****************************************************/
/* menu                                              */
/* objetivo: rotina para montar menu da aplicacao    */
/* entrada : menu                                    */
/* saída   : menu                                    */
/*****************************************************/
void menu_principal(){
	printf( " +---------------------------------------------------------+" );
    printf( "\n | Programa registro de pessoas - Menu                     |" );
	printf( "\n |---------------------------------------------------------|" );
    printf( "\n |[1 ] Cria lista                                          |" );
    printf( "\n |[2 ] Inclui registro no final da lista                   |" );
    printf( "\n |[3 ] Exclui registro                                     |" );
    printf( "\n |[4 ] Altera lista                                        |" ); 
    printf( "\n |[5 ] Ordena lista                                        |" ); 		     
    printf( "\n |[6 ] Consulta por nome                                   |" );                                 
    printf( "\n |[7 ] Imprime lista                                       |" );
    printf( "\n |[0 ] Para sair do programa                               |" );
    printf( "\n +---------------------------------------------------------+" );
    printf( "\n Opção: " );
}