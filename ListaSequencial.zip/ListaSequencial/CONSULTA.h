void consulta_nome (NODO lista){
	system("cls");
	
	if(lista->f < 1) 
		printf("A lista esta vazia!");
	else{
		printf(   " +---------------------------------------------------------+" );
		printf( "\n | Consulta de Paciente                                    |" );
		printf( "\n +---------------------------------------------------------+" );
		
		printf( "\n\t Insira o código: " );
		fflush(stdin);
		scanf("%i", &cod);
		
		for(i = 0; i < lista->f; i++){
			if(cod != lista->info[i].codigo){
				printf("Código não encontrado.");
			}
			else{
				
			}
		}
	}
}