void consulta_nome (NODO lista){
	system("cls");
	
	if(lista->f < 1) 
		printf("A lista esta vazio!");
	
}