void inclui_fim ( NODO *lista ){
	system ( "cls" );
	
	if( lista->f < N_MAX ){
		printf("===== Modo Inclusão de Paciente(s)\n");
		printf("==================================\n");
		printf("=== Código: ");
		fflush(stdin);
		scanf("%i", &lista->info[lista->f].codigo);
		fflush(stdin);
		printf("=== Nome: ");
		gets(lista->info[lista->f].nome);
		
		lista->f++;
	}
	else
		printf( "Lista cheia!!!" );
}