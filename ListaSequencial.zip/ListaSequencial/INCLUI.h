void inclui_fim ( NODO *lista ){
	if( lista->f < 1)
		printf( "Lista est
}