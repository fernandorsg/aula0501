/*************************************************/
/* inclui_fim                                    */
/* objetivo: rotina para incluir dados           */
/* entrada : lista                               */
/* saída   : nenhuma, apenas em tela             */
/*************************************************/
void inclui_fim ( NODO *lista ){
	system ( "cls" );
	
	if( lista->f < N_MAX ){
		
		printf( " +---------------------------------------------------------+" );
		printf( "\n | Inclusão de Paciente(s)                                 |" );
		printf( "\n +---------------------------------------------------------+" );
		printf( "\n\t Insira o código: " );
		fflush(stdin);
		scanf("%i", &lista->info[lista->f].codigo);
		fflush(stdin);
		printf( "\n\t Insira o nome: " );
		gets(lista->info[lista->f].nome);
		
		char str[] = lista->info[lista->f].nome;
   
		while(str[i]) {
			putchar (toupper(str[i]));
			i++;
		}
		
		lista->f++;
	}
	else
		printf( "Lista cheia!" );
}