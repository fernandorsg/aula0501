/*************************************************/
/* exclui_nodo                                   */
/* objetivo: rotina para excluir dados           */
/* entrada : codigo                              */
/* saída   : nenhuma, apenas em tela             */
/*************************************************/

void exclui_nodo ( NODO *lista ){
	system ( "cls" );
	
	//int i = 0;
	
	if( lista->f > 0 ){
		printf( " +---------------------------------------------------------+" );
		printf( "\n | Modo Exclusão de Paciente(s)                            |" );
		printf( "\n +---------------------------------------------------------+" );
		
		while( i <= lista->f ){
			printf("\n |\t %i \t\t %s|", lista->info[ i ].codigo, lista->info[ i ].nome);
			i++;
		}
		
		printf( "\n +---------------------------------------------------------+" );
		printf( "\n\t Insira o código: " );
		fflush(stdin);
		scanf("%i", &cod);
				
		for( int j = 0; j <= lista->f; j++ ){
			if( cod == lista->info[ j ].codigo ){
				lista->info[ j ] = lista->info[ j + 1 ];
			}
			else{
				printf("Código não localizado!");
			}
		}
		
		lista->f--;
	}
	else {
		printf("Lista de paciente(s) esta vazia!");
	}
}