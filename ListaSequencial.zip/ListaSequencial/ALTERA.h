/*************************************************/
/* altera_nodo                                   */
/* objetivo: rotina para alterar dados           */
/* entrada : codigo e/ou nome                    */
/* saída   : nenhuma, apenas em tela             */
/*************************************************/

void altera_nodo ( NODO *lista ){
	system ( "cls" );
	
	//int i = 0;
	
	if( lista->f > 0){
		printf( " +---------------------------------------------------------+" );
		printf( "\n | Modo Alteração de Paciente(s)                           |" );
		printf( "\n +---------------------------------------------------------+" );
		
		while( i <= lista->f ){
			printf("\n |\t %i \t\t %s|", lista->info[ i ].codigo, lista->info[ i ].nome);
			i++;
		}
		
		printf( "\n +---------------------------------------------------------+" );
		printf( "\n\t Insira o código: " );
		fflush(stdin);
		scanf("%i", &cod);
		
		for(int j = 0; j < lista->f; j++){
			if(cod == lista->info[ j ].codigo){
				printf("Digite o novo nome: ");
				gets(lista->info[ j ].nome);
				printf("O nome foi alterado com sucesso!");
			}
			else{
				printf("Código não localizado!");
			}
		}
	}
	else{
		printf("Lista de paciente(s) esta vazia!");
	}
}