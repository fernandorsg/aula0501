/***********************************************/
/* Lista Sequencial                            */
/* objetivo: controle de registros             */
/* programador: Daniela Bagatini               */
/* criado em: 20/08/2017                       */
/* data da �ltima altera��o: 22/07/2018        */
/***********************************************/

#include <stdio.h>
#include <stdlib.h>     // exit, system("cls")
#include <string.h>     // strcmp
#include <locale.h>     // setlocale

#include "MODELOSEQ.h"
#include "MENU_PRINCIPAL.h"
#include "CRIA.h"
#include "IMPRIME.h"
#include "INCLUI.h"
#include "EXLCUI.h"
#include "ALTERADO.h"
#include "ORDENA.h"

#define N_MAX 20     // n�mero m�ximo de registros

/***********************************************/
/* Defini��o das Fun��es                       */
/***********************************************/
void entrada_dados  ( INFORMACAO *aux );     // leitura dos dados de entrada
void menu			();                      // menu de op�oes da aplicacao
void imprime_lista  ( NODO lista );          // visualiza��o da lista em tela
void cria_lista     ( int *fim );            // inicializa lista com tamanho 0
void inclui_fim     ( NODO *lista );         // inclui um novo registro no final da lista
void exclui_nodo    ( NODO *lista );         // exclui um regitro por c�digo
void altera_nodo    ( NODO *lista );         // altera um regitro a partir de um c�digo de refer�ncia
void ordena_lista   ( NODO *lista );         // ordena por c�digo - ordem crescente 
void consulta_nome  ( NODO lista );          // consulta por nome de refer�ncia

/***********************************************/
/* Programa Principal                          */
/***********************************************/
int main( void )
{
    int op;           					// op��o do menu
    NODO lista;       					// vari�vel do tipo lista sequencial = vetor de registros
    setlocale( LC_ALL, "Portuguese" );	// definindo o local e idioma para Portugues-BR

    while( 1 ){
		menu();				// funcao que traz o menu para a aplicacao
        fflush( stdin );   	// limpa buffer do teclado, funciona antes da entrada de dados
        scanf( "%i", &op );	// tecla de op��o do menu
         
        switch( op ) {
            case 1:  // rotina cria lista
                cria_lista( &lista.f );
                break;

            case 2:// rotina inclui registro no final da lista
				inclui_fim( &lista );
                break;

            case 3:  // rotina exclui registro conforme c�digo
                exclui_nodo( &lista );
                break;

            case 4: // rotina ordena lista por c�digo
				altera_nodo( &lista );
                break;
                    
            case 5: // rotina altera nodo = registro
                ordena_lista( &lista ); // VAR. LISTA � PASSADA POR REFER�NCIA
                break;
                    
            case 6: // rotina consulta nome na lista
                //consulta_nome( lista );
                break;    
                                       
            case 7: // rotina imprime lista
                imprime_lista( lista );
                break;
                    
            case 0: // t�rmino do programa
                exit( 1 );
                break;

            default :
                printf( "\n Digite uma op��o!" );
                break;
        } // fim switch( op )
        printf( "\n\n" );
        system( "pause" );
        system( "cls" );
    } // fim do while( 1 )
	return 0;
} // fim do programa principal