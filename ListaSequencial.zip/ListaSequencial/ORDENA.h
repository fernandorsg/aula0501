/*************************************************/
/* ordena_nodo                                   */
/* objetivo: rotina para ordenar os dados        */
/* entrada : ordena                              */
/* saída   : nenhuma                             */
/*************************************************/

void ordena_nodo ( NODO *lista){
	system("cls");
	
	if(lista->f == 0)
		printf("A lista esta vazia!");
	else if(lista->f == 1)
		printf("A lista possui apenas um paciente cadastrado!");
	else {
		for(int i = 0; i < lista->f-1; i++){
			int ordena = lista->info[i];
			for(int j = i+1; j < lista->f; j++){
				if(lista->info[j].codigo < ordena){
					ordena = lista->info[j];
				}
			}
			if(i != ordena){
				int troca = lista->info[i];
				lista->info[i] = lista->info[ordena];
				lista->info[ordena] = troca;
			}
		}
	}
}