/*************************************************
 * imprime_lista                                 *
 * objetivo: rotina para imprimir dados          *
 * entrada : lista                               *
 * saída   : nenhuma, apenas em tela             *
 *************************************************/
void imprime_lista( NODO lista ){

    if( lista.f == 0 )                 // lista vazia
        printf( "Lista vazia!" );
	
	printf( " +---------------------------------------------------------+" );
	printf( "\n | Lista de Paciente(s)                                    |" );
	printf( "\n +---------------------------------------------------------+" );
	printf( "\n\t Código \t\t Nome " );
	
    for( i = 0 ; i < lista.f ; i++ ){ // percorre a lista
         printf( "\n |\t %d \t\t %s|", lista.info[ i ].codigo, lista.info[ i ].nome );	 
    }
	printf( "\n +---------------------------------------------------------+" );
}