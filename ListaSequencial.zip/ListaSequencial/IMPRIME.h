/*************************************************
 * imprime_lista                                 *
 * objetivo: rotina para imprimir dados          *
 * entrada : lista                               *
 * saída   : nenhuma, apenas em tela             *
 *************************************************/
void imprime_lista( NODO lista ){
     
    int i; // índice do laço

    if( lista.f == 0 )                 // lista vazia
        printf( "\n Lista vazia!" );

    for( i = 0 ; i < lista.f ; i++ ) { // percorre a lista
         printf( "\n Código...: %d", lista.info[ i ].codigo );
         printf( "\n Nome.....: %s", lista.info[ i ].nome );
    }
}