/***********************************************/ 
/* Defini��o dos Registros                       */
/***********************************************/ 
#define N_MAX   20

typedef struct {                                          // registro para uma pessoa       
	int  codigo;       
	char nome[30];
}INFORMACAO; 
      
typedef struct {       
	INFORMACAO info[N_MAX];    // dados do registro       
	int f;                                            // n�mero de registro(s) ocupado(s) na estrutura
}NODO;                                                      // estrutura do tipo NODO
