/*******
 * APS *
 *******/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

typedef struct

/************************************
 * Definicao das funcoes do sistema *
 ************************************/
void    cria_lista     ( NODO* *lista );  // inicializa lista com NULL
void    entrada_dados  ( NODO *auxiliar ); // leitura dos dados de entrada
void    imprime_lista  ( NODO *auxiliar ); // visualiza��o de toda lista em tela
void    inclui_fim     ( NODO* *lista );  // inclui um novo registro no final da lista
void    inclui_inicio  ( NODO* *lista );  // inclui um novo registro no in�cio da lista, ser� o primeiro registro da lista
NODO*   procura_nodo( NODO* lista, int codigo ); // procura por um c�digo na lista e retorna o endere�o do registro que cont�m o c�digo
void    exclui_nodo    ( NODO* *lista );  // exclui um registro por c�digo 
void    ordena_lista   ( NODO* *lista );  // ordena lista por c�digo, ordem crescente
void    inclui_ordenado( NODO* *lista );  // inclui registro na lista de forma ordenada por c�digo, considera-se que a lista est� ordenada (caso n�o, chamar ordena lista antes)
void    inverte        ( NODO* *lista );  // inverte refer�ncia dos registros, o �ltimo passa a ser o primeiro registro da lista, o primeiro passa a ser o �ltimo, os demais registros invertem o sentido do apontamento (da direita para a esquerda)
void    consulta_nome  ( NODO* lista );   // consulta por um nome na lista
void    inserir_antes  ( NODO* *lista );  // inserir novo registro antes de um c�digo de refer�ncia informado pelo usu�rio
void    inserir_depois ( NODO* *lista );  // inserir novo registro depois de um c�digo de refer�ncia  informado pelo usu�rio
void    conta_nodo     ( NODO* *lista );  // contar e aprensetar o n�mero de registros existentes na lista

int main(void){
	setlocale(LC_ALL, "Portuguese");
	
	int opcao; // variavel inteiro para controlar qual opcao do menu e selecionado
	
	printf( " +-------------------------------------------------------------+" );
    printf( "\n | Menu - Entregas de Pizza                                    |" );
	printf( "\n |-------------------------------------------------------------|" );
    printf( "\n |[1 ] Cria lista                                              |" );
    printf( "\n |[2 ] Entradas de dados de entregas                           |" );
    printf( "\n |[3 ] Imprime lista de entregas                               |" );
    printf( "\n |[4 ] Inclui no final da lista de pedidos                     |" ); 
    printf( "\n |[5 ] Inclui no in�cio da lista de pedidos                    |" ); 		     
    printf( "\n |[6 ] Procura NODO                                            |" );                                 
    printf( "\n |[7 ] Exclui uma entrega                                      |" );
	printf( "\n |[8 ] Ordena a lista de entregas                              |" );
	printf( "\n |[9 ] Inclui entrega ordenando                                |" );
	printf( "\n |[10] Inverte ordem de entregas                               |" );
	printf( "\n |[11] Consulta nome entregador                                |" );
	printf( "\n |[12] Inserir antes de uma entrega referenciada pelo usu�rio  |" );
	printf( "\n |[13] Inserir ap�s uma entrega referenciada pelo usu�rio      |" );
	printf( "\n |[14] Contar entregas                                         |" ); 
    printf( "\n |[0 ] Para sair do programa                                   |" );
    printf( "\n +-------------------------------------------------------------+" );
    printf( "\n Opcao: " );
    scanf("%i", &opcao);
	
	while ( 1 ){
		switch( opcao ){
		case 1:
			cria_lista( *lista );
			break;
		case 2:
			//entrada_dados( *auxiliar );
			break;
		case 3:
			
	}
	}
	
	return 0;
}

void cria_lista( NODO* *lista){
	*lista = NULL; // lista criada com inicio NULL
}
